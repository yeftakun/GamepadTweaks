# Gamepad Tweaks for Assetto Corsa

**Gamepad Tweaks** is a Custom Shaders Patch (CSP) Gamepad FX script and in-game UI app. It provides precise calibration for Hall Effect triggers and gives you full control over how game vibrations are separated and routed to your controller's haptic motors.

![preview](assets/preview.png)

## Features

- **Trigger Calibration:** Hysteresis and EMA smoothing to eliminate deadzones and signal noise.
- **Response Curve:** Reshape how trigger pressure maps to output with an adjustable curve. Dull light presses so your throttle finger feels less twitchy, or sharpen them for a quicker brake bite.
- **Trigger Vibration:** Independent haptic feedback directly tied to your throttle (RT) and brake (LT) inputs.
- **Discrete Native Haptics:** Separate and route native game effects (ABS, Slip, Kerbs, Gearshift, Engine RPM, etc.) to specific motors (Left/Low Freq, Right/High Freq, or Both).

## Setup & Installation

For the complete installation guide, requirements, and the latest releases, please visit the official page on Overtake.gg:

🔗 **[Download & Setup Guide on Overtake.gg](https://www.overtake.gg/downloads/gamepad-tweaks-hall-trigger-deadzone-fix-haptic-feedback.86222/)**
